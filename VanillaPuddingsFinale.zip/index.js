$(document).ready(function(){



	$("#01").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#01").mouseover(function(){
        $("#01").css({ width: '150px', height: '150px'});
    });

    $("#01").mouseout(function(){
        $("#01").css({ width: '100px', height: '100px'});
    });

    $("#02").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#02").mouseover(function(){
        $("#02").css({ width: '150px', height: '150px'});
    });

    $("#02").mouseout(function(){
        $("#02").css({ width: '100px', height: '100px'});
    });

    $("#03").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#03").mouseover(function(){
        $("#03").css({ width: '150px', height: '150px'});
    });

    $("#03").mouseout(function(){
        $("#03").css({ width: '100px', height: '100px'});
    });

    $("#04").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#04").mouseover(function(){
        $("#04").css({ width: '150px', height: '150px'});
    });

    $("#04").mouseout(function(){
        $("#04").css({ width: '100px', height: '100px'});
    });

    $("#05").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#05").mouseover(function(){
        $("#05").css({ width: '150px', height: '150px'});
    });

    $("#05").mouseout(function(){
        $("#05").css({ width: '100px', height: '100px'});
    });

    $("#06").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#06").mouseover(function(){
        $("#06").css({ width: '150px', height: '150px'});
    });

    $("#06").mouseout(function(){
        $("#06").css({ width: '100px', height: '100px'});
    });

    $("#07").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#07").mouseover(function(){
        $("#07").css({ width: '150px', height: '150px'});
    });

    $("#07").mouseout(function(){
        $("#07").css({ width: '100px', height: '100px'});
    });

    $("#08").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#08").mouseover(function(){
        $("#08").css({ width: '150px', height: '150px'});
    });

    $("#08").mouseout(function(){
        $("#08").css({ width: '100px', height: '100px'});
    });

    $("#09").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#09").mouseover(function(){
        $("#09").css({ width: '150px', height: '150px'});
    });

    $("#09").mouseout(function(){
        $("#09").css({ width: '100px', height: '100px'});
    });

    $("#10").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#10").mouseover(function(){
        $("#10").css({ width: '150px', height: '150px'});
    });

    $("#10").mouseout(function(){
        $("#10").css({ width: '100px', height: '100px'});
    });

    $("#11").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#11").mouseover(function(){
        $("#11").css({ width: '150px', height: '150px'});
    });

    $("#11").mouseout(function(){
        $("#11").css({ width: '100px', height: '100px'});
    });

    $("#12").click(function(){
				$("#bigImg").attr("src",$(this).attr("src"));
    });

    $("#12").mouseover(function(){
        $("#12").css({ width: '150px', height: '150px'});
    });

    $("#12").mouseout(function(){
        $("#12").css({ width: '100px', height: '100px'});
    });
});
